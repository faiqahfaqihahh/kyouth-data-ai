import sqlite3
from pathlib import Path

def run_data_profile(db_path):
    if not Path(db_path).exists():
        print(f"❌ Database not found at {db_path}")
        return

    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM jobs")
    total_records = cursor.fetchone()[0]

    if total_records == 0:
        print("--- 🔍 DATA QUALITY REPORT ---")
        print("📈 Total Records: 0")
        print("❓ Missing Values -> job_title: 0, company: 0, description: 0")
        print("📝 Avg Description Length: 0 chars")
        conn.close()
        return

    cursor.execute("""
        SELECT 
            SUM(CASE WHEN job_title IS NULL OR job_title = '' THEN 1 ELSE 0 END),
            SUM(CASE WHEN company IS NULL OR company = '' THEN 1 ELSE 0 END),
            SUM(CASE WHEN description IS NULL OR description = '' THEN 1 ELSE 0 END)
        FROM jobs
    """)
    missing_title, missing_company, missing_desc = cursor.fetchone()

    cursor.execute("SELECT AVG(LENGTH(description)) FROM jobs")
    avg_desc_len = int(cursor.fetchone()[0] or 0)

    cursor.execute("""
        SELECT source_id, job_title, LENGTH(description) 
        FROM jobs 
        ORDER BY LENGTH(description) ASC 
        LIMIT 1
    """)
    short_id, short_title, short_len = cursor.fetchone()

    cursor.execute("""
        SELECT source_id, job_title, LENGTH(description) 
        FROM jobs 
        ORDER BY LENGTH(description) DESC 
        LIMIT 1
    """)
    long_id, long_title, long_len = cursor.fetchone()

    conn.close()

    print("--- 🔍 DATA QUALITY REPORT ---")
    print(f"📈 Total Records: {total_records}")
    print(f"❓ Missing Values -> job_title: {missing_title or 0}, company: {missing_company or 0}, description: {missing_desc or 0}")
    print(f"📝 Avg Description Length: {avg_desc_len} chars")
    print(f"⚠️ Shortest Description: {short_len} chars")
    print(f"   ↳ source_id: {short_id} | job_title: {short_title}")
    print(f"🚨 Longest Description: {long_len} chars")
    print(f"   ↳ source_id: {long_id} | job_title: {long_title}")