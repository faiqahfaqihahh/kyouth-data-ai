import json
import sqlite3
from pathlib import Path


def load_all_jsons(input_dir, output_dir):
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    print("🥇 Gold:...")

    # Idempotency: create output dir if missing
    output_path.mkdir(parents=True, exist_ok=True)

    if not input_path.exists() or not any(input_path.iterdir()):
        print("⚠️  Silver directory is empty or does not exist.")
        print("📊 Gold Summary:")
        print("Total: 0 | Inserted: 0 | Skipped: 0")
        return

    db_path = output_path / "jobs.db"
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Create table if not exists
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
            source_id   TEXT PRIMARY KEY,
            job_title   TEXT,
            company     TEXT,
            description TEXT,
            tech_stack  TEXT
        )
        """
    )
    connection.commit()

    json_files = list(input_path.glob("*.json"))
    total = len(json_files)
    inserted = 0
    skipped = 0

    for json_file in json_files:
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Check rows before insert to detect duplicates
            cursor.execute("SELECT source_id FROM jobs WHERE source_id = ?", (data["source_id"],))
            exists = cursor.fetchone()

            cursor.execute(
                """
                INSERT OR IGNORE INTO jobs (source_id, job_title, company, description, tech_stack)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    data["source_id"],
                    data["job_title"],
                    data["company"],
                    data["description"],
                    None,
                ),
            )
            connection.commit()

            if exists:
                print(f"⏭️  Skipped (duplicate): {json_file.name}")
                skipped += 1
            else:
                print(f"✅ Inserted: {json_file.name}")
                inserted += 1

        except Exception as e:
            print(f"❌ Error loading {json_file.name}: {e}")
            skipped += 1

    connection.close()

    print("📊 Gold Summary:")
    print(f"Total: {total} | Inserted: {inserted} | Skipped: {skipped}")
