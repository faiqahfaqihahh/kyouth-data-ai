import sqlite3
from pathlib import Path


def run_data_profile(db_path):
    path = Path(db_path)

    if not path.exists():
        print(f"❌ Database not found at {db_path}")
        return

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Total records
    cursor.execute("SELECT COUNT(*) FROM jobs")
    total = cursor.fetchone()[0]

    # Null counts
    cursor.execute(
        """
        SELECT
            SUM(CASE WHEN job_title IS NULL OR job_title = '' THEN 1 ELSE 0 END),
            SUM(CASE WHEN company IS NULL OR company = '' THEN 1 ELSE 0 END),
            SUM(CASE WHEN description IS NULL OR description = '' THEN 1 ELSE 0 END)
        FROM jobs
        """
    )
    null_title, null_company, null_desc = cursor.fetchone()

    # Average description length
    cursor.execute("SELECT AVG(LENGTH(description)) FROM jobs WHERE description IS NOT NULL")
    avg_len = cursor.fetchone()[0]

    # Shortest description
    cursor.execute(
        """
        SELECT source_id, job_title, LENGTH(description) as len
        FROM jobs
        WHERE description IS NOT NULL
        ORDER BY len ASC
        LIMIT 1
        """
    )
    shortest = cursor.fetchone()

    # Longest description
    cursor.execute(
        """
        SELECT source_id, job_title, LENGTH(description) as len
        FROM jobs
        WHERE description IS NOT NULL
        ORDER BY len DESC
        LIMIT 1
        """
    )
    longest = cursor.fetchone()

    connection.close()

    print("\n--- 🔍 DATA QUALITY REPORT ---")
    print(f"📈 Total Records: {total}")
    print(f"❓ Missing Values -> job_title: {null_title}, company: {null_company}, description: {null_desc}")
    print(f"📝 Avg Description Length: {int(avg_len) if avg_len else 0} chars")

    if shortest:
        print(f"⚠️  Shortest Description: {shortest[2]} chars")
        print(f"   ↳ source_id: {shortest[0]} | job_title: {shortest[1]}")

    if longest:
        print(f"🚨 Longest Description: {longest[2]} chars")
        print(f"   ↳ source_id: {longest[0]} | job_title: {longest[1]}")
