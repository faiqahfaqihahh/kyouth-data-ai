import json
from pathlib import Path

from bs4 import BeautifulSoup


class JobListing:
    """Pydantic-style data contract for job listings (all fields must be non-empty strings)."""

    def __init__(self, source_id: str, job_title: str, company: str, description: str):
        for field, value in [
            ("source_id", source_id),
            ("job_title", job_title),
            ("company", company),
            ("description", description),
        ]:
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"Field '{field}' must be a non-empty string, got: {value!r}")
        self.source_id = source_id.strip()
        self.job_title = job_title.strip()
        self.company = company.strip()
        self.description = description.strip()

    def model_dump(self):
        return {
            "source_id": self.source_id,
            "job_title": self.job_title,
            "company": self.company,
            "description": self.description,
        }


def process_all_html(input_dir, output_dir):
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    print("🥈 Silver:...")

    output_path.mkdir(parents=True, exist_ok=True)

    if not input_path.exists() or not any(input_path.iterdir()):
        print("⚠️  Bronze directory is empty or does not exist.")
        print("📊 Silver Summary:")
        print("Total: 0 | Processed: 0 | Skipped: 0")
        return

    html_files = list(input_path.glob("*.html"))
    total = len(html_files)
    processed = 0
    skipped = 0

    for html_file in html_files:
        try:
            with open(html_file, "r", encoding="utf-8") as f:
                html = f.read()

            soup = BeautifulSoup(html, "html.parser")

            # source_id from og:url
            og_url_tag = soup.find("meta", property="og:url")
            source_id = None
            if og_url_tag and og_url_tag.get("content"):
                url = og_url_tag["content"].rstrip("/")
                source_id = url.split("?")[0].split("/")[-1]

            # job_title
            title_tag = soup.find(attrs={"data-automation": "job-detail-title"})
            job_title = title_tag.get_text(separator=" ", strip=True) if title_tag else None

            # company
            company_tag = soup.find(attrs={"data-automation": "advertiser-name"})
            if company_tag:
                company = company_tag.get_text(separator=" ", strip=True)
            else:
                cp_tag = soup.find(attrs={"data-automation": "company-profile"})
                if cp_tag:
                    company = cp_tag.get_text(separator=" ", strip=True).split("·")[0].strip()
                else:
                    company = None

            # description
            desc_tag = soup.find(attrs={"data-automation": "jobAdDetails"})
            description = desc_tag.get_text(separator=" ", strip=True) if desc_tag else None

            skip = False
            if not source_id:
                print(f"⚠️  Missing source_id in: {html_file.name}")
                skip = True
            if not job_title:
                print(f"⚠️  Missing job_title in: {html_file.name}")
                skip = True
            if not company:
                print(f"⚠️  Missing company in: {html_file.name}")
                skip = True
            if not description:
                print(f"⚠️  Missing description in: {html_file.name}")
                skip = True

            if skip:
                skipped += 1
                continue

            listing = JobListing(
                source_id=source_id,
                job_title=job_title,
                company=company,
                description=description,
            )

            output_file = output_path / (html_file.stem + ".json")
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(listing.model_dump(), f, ensure_ascii=False, indent=2)

            print(f"✅ Processed: {html_file.name}")
            processed += 1

        except ValueError as e:
            print(f"❌ Validation error in {html_file.name}: {e}")
            skipped += 1
        except Exception as e:
            print(f"❌ Error processing {html_file.name}: {e}")
            skipped += 1

    print("📊 Silver Summary:")
    print(f"Total: {total} | Processed: {processed} | Skipped: {skipped}")
